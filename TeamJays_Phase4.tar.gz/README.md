# TeamJays

### Brian Domingo

### Saif Niaz

### Samuel Mccabe

**How to run:**

- Redirect working directory to '/backend/src/'
- Either run './backend.sh' or 'make comp' followed by 'make comp1'
