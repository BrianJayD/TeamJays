#! /bin/bash

javac *.java

java main

rm *.class
